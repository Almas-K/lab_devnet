ALTER ROLE db_datareader
    ADD MEMBER ALMAS;  
GO