package com.example.lab1;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

public class MainActivity extends AppCompatActivity {
    private EditText input;
    private static Cipher encryptionCipher;
    private static SecretKey key;
    private static final int KEY_SIZE = 128;
    private static final int T_LEN = 128;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        input = findViewById(R.id.inputText);
    }

    // Обработка нажатия кнопки
    public void sendMessage(View view) {
        TextView output = findViewById(R.id.output);
        String s;
        String message = input.getText().toString();
        try {
            KeyGenerator generator = KeyGenerator.getInstance("AES");
            generator.init(KEY_SIZE);
            key = generator.generateKey();
            byte[] messageInBytes = message.getBytes();
            encryptionCipher = Cipher.getInstance("AES/GCM/NoPadding");
            encryptionCipher.init(Cipher.ENCRYPT_MODE, key);
            byte[] encryptedBytes = encryptionCipher.doFinal(messageInBytes);
            s = encryptedBytes.toString();
        } catch (Exception e) {
            s = "Error";
        }
        output.setText("Шифровка: " + s + "\n");
    }
}